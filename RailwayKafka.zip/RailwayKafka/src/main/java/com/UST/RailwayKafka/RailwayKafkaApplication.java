package com.UST.RailwayKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwayKafkaApplication.class, args);
	}

}
