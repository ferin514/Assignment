package com.UST.RailwayKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
